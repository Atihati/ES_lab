################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../test/unity/unity.c 

C_DEPS += \
./test/unity/unity.d 

OBJS += \
./test/unity/unity.obj 

OBJS__QUOTED += \
"test\unity\unity.obj" 

C_DEPS__QUOTED += \
"test\unity\unity.d" 

C_SRCS__QUOTED += \
"../test/unity/unity.c" 


