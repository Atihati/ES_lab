################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../test/testHalGeneral.c 

C_DEPS += \
./test/testHalGeneral.d 

OBJS += \
./test/testHalGeneral.obj 

OBJS__QUOTED += \
"test\testHalGeneral.obj" 

C_DEPS__QUOTED += \
"test\testHalGeneral.d" 

C_SRCS__QUOTED += \
"../test/testHalGeneral.c" 


