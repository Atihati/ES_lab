################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../test/tstHAL/testHalCleanUp.c \
../test/tstHAL/testHalGPIO.c 

C_DEPS += \
./test/tstHAL/testHalCleanUp.d \
./test/tstHAL/testHalGPIO.d 

OBJS += \
./test/tstHAL/testHalCleanUp.obj \
./test/tstHAL/testHalGPIO.obj 

OBJS__QUOTED += \
"test\tstHAL\testHalCleanUp.obj" \
"test\tstHAL\testHalGPIO.obj" 

C_DEPS__QUOTED += \
"test\tstHAL\testHalCleanUp.d" \
"test\tstHAL\testHalGPIO.d" 

C_SRCS__QUOTED += \
"../test/tstHAL/testHalCleanUp.c" \
"../test/tstHAL/testHalGPIO.c" 


