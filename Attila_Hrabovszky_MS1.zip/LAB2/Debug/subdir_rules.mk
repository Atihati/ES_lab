################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
%.obj: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: MSP430 Compiler'
	"C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/bin/cl430" -vmspx --data_model=restricted -Ooff --use_hw_mpy=F5 --include_path="C:/ES_repo/workspace_v12/LAB2/AL" --include_path="C:/ES_repo/workspace_v12/LAB2/test" --include_path="C:/ES_repo/workspace_v12/LAB2/test/unity" --include_path="C:/ES_repo/workspace_v12/LAB2/test/tstHAL" --include_path="C:/ES_repo/workspace_v12/LAB2/DL" --include_path="C:/ti/ccs1280/ccs/ccs_base/msp430/include" --include_path="C:/ES_repo/workspace_v12/LAB2/HAL" --include_path="C:/ES_repo/workspace_v12/LAB2" --include_path="C:/ti/ccs1280/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include" --advice:power=all --define=__MSP430F5335__ --define=UNITY_INCLUDE_CONFIG_H -g --printf_support=minimal --diag_warning=225 --diag_wrap=off --display_error_number --silicon_errata=CPU21 --silicon_errata=CPU22 --silicon_errata=CPU40 --preproc_with_compile --preproc_dependency="$(basename $(<F)).d_raw" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


