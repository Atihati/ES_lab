################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../HAL/halGeneral.c \
../HAL/halGpio.c \
../HAL/halPMM.c \
../HAL/halTimerB0.c \
../HAL/halUCS.c \
../HAL/halWdt.c 

C_DEPS += \
./HAL/halGeneral.d \
./HAL/halGpio.d \
./HAL/halPMM.d \
./HAL/halTimerB0.d \
./HAL/halUCS.d \
./HAL/halWdt.d 

OBJS += \
./HAL/halGeneral.obj \
./HAL/halGpio.obj \
./HAL/halPMM.obj \
./HAL/halTimerB0.obj \
./HAL/halUCS.obj \
./HAL/halWdt.obj 

OBJS__QUOTED += \
"HAL\halGeneral.obj" \
"HAL\halGpio.obj" \
"HAL\halPMM.obj" \
"HAL\halTimerB0.obj" \
"HAL\halUCS.obj" \
"HAL\halWdt.obj" 

C_DEPS__QUOTED += \
"HAL\halGeneral.d" \
"HAL\halGpio.d" \
"HAL\halPMM.d" \
"HAL\halTimerB0.d" \
"HAL\halUCS.d" \
"HAL\halWdt.d" 

C_SRCS__QUOTED += \
"../HAL/halGeneral.c" \
"../HAL/halGpio.c" \
"../HAL/halPMM.c" \
"../HAL/halTimerB0.c" \
"../HAL/halUCS.c" \
"../HAL/halWdt.c" 


